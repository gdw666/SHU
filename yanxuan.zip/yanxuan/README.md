# async-spider

![License](https://img.shields.io/badge/License-Apache2.0-brightgreen) ![License](https://img.shields.io/badge/Version-v0.1-yellow)

Baidu Library Analysis and Download

### prerequisite

> Learn a little python basics  

### Running the tests

>The Anaconda environment or Python interpreter must be installed on the native computer

### Built with

>Use the command to install the required dependencies in one go

```python
pip install -r requirements.txt
```

### Contributing

>[Github Issues](https://github.com/waahah/async-spider/issues)
