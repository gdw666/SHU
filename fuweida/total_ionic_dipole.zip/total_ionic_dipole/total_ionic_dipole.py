def process_structure_files(initial_file, data_file):
    # 读取初始结构文件
    with open(initial_file, 'r') as f:
        initial_lines = f.readlines()

    # 读取数据文件
    with open(data_file, 'r') as f:
        data_lines = f.readlines()

    # 提取初始结构的晶格常数
    lattice_constants = []
    for i in range(2, 5):
        lattice_constants.append([float(x) for x in initial_lines[i].split()])
    lattice_constants = [lattice_constants[0][0],lattice_constants[1][1],lattice_constants[2][2]] 
    print("晶格常数：")
    print(lattice_constants)
    
    # 记录原子位置变化
    atom_changes = []
    atom_start_line = 8  # 原子信息起始行为第9行
    atom_end_line = atom_start_line + sum(int(x) for x in initial_lines[6].split())  # 根据原子数总和计算结束行
    print("从第"+str(atom_start_line+1)+"行到第"+str(atom_end_line)+"行")
    for i in range(atom_start_line, atom_end_line):
        initial_coords = [float(x) for x in initial_lines[i].split()[0:3]]
        data_coords = [float(x) for x in data_lines[i].split()[0:3]]
        # 考虑周期性边界条件
        atom_change = [(data_coords[j] - initial_coords[j]) * lattice_constants[j] for j in range(3)]

        # 如果原子坐标超出晶格范围，则进行修正
        for j in range(3):
            if atom_change[j] > lattice_constants[j] / 2:
                atom_change[j] -= lattice_constants[j]
            elif atom_change[j] < -lattice_constants[j] / 2:
                atom_change[j] += lattice_constants[j]

        atom_changes.append(atom_change)
        
    print(atom_changes)
    # 获取最外层电子数
    atomic_numbers = [14, 7, 9, 5, 1, 4]  # 根据给定的原子种类顺序，对应Pb, Br, Cs, N, H, C的最外层电子数

    # 计算电子数乘以原子位置变化的总和
    sums = [0, 0, 0]
    for i in range(len(atom_changes)):
        for j in range(3):
            sums[j] += atom_changes[i][j] * atomic_numbers[j]

    # 输出在x、y、z三个方向上的总和
    print("Total sum in x-direction:", sums[0])
    print("Total sum in y-direction:", sums[1])
    print("Total sum in z-direction:", sums[2])
    return [sums[0],sums[1],sums[2]]
def process_multiple_files(initial_file, data_files, output_file):
    # 创建Excel文件
    workbook = openpyxl.Workbook()
    sheet = workbook.active

    for data_file in data_files:
        # 调用处理函数并获取结果
        result = process_structure_files(initial_file, data_file)

        # 写入结果到工作表
        sheet.append([data_file])
        sheet.append(["Total sum in x-direction:", result[0]])
        sheet.append(["Total sum in y-direction:", result[1]])
        sheet.append(["Total sum in z-direction:", result[2]])

    # 保存Excel文件
    workbook.save(output_file)

# 调用函数处理结构文件并写入Excel
initial_structure_file = "CONTCAR_00"  # 替换为实际的初始结构文件名
data_structure_files = ["CONTCAR_01", "CONTCAR_02", "CONTCAR_03", "CONTCAR_04", "CONTCAR_05", "CONTCAR_06", "CONTCAR_07", "CONTCAR_08", "CONTCAR_09", "CONTCAR_10"]  # 替换为实际的数据结构文件名列表
output_excel_file = "results.xlsx"  # 替换为实际的输出Excel文件名
process_multiple_files(initial_structure_file, data_structure_files, output_excel_file)
