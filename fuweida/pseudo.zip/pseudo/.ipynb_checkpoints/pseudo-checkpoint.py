import os

def read_vas_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        elements = lines[5].split()
        atom_counts = list(map(int, lines[6].split()))
        atom_info = [line.split() for line in lines[8:]]
        head = [line.split() for line in lines[0:8]]
    return elements, atom_counts, atom_info, head

def transform_coordinates(atom_info, target_indices, step):
    
    
    new_atom_info = atom_info.copy()

    for index in range(target_indices):
        y_coordinate = float(atom_info[index][1])
        z_coordinate = float(atom_info[index][2])

        target_y = min([0, 0.25, 0.5, 0.75, 1], key=lambda x: abs(x - y_coordinate))
        target_z = min([0, 0.25, 0.5, 0.75, 1], key=lambda x: abs(x - z_coordinate))

        new_y = y_coordinate + (target_y - y_coordinate) * step / 10
        new_z = z_coordinate + (target_z - z_coordinate) * step / 10

        new_atom_info[index][1] = str(format(new_y, '.16f'))
        new_atom_info[index][2] = str(format(new_z, '.16f'))

    return new_atom_info

def main():
    input_file = '4monoconter.vas'
    elements, atom_counts, atom_info, head = read_vas_file(input_file)
    print(head)
    print(elements)
    print(atom_counts)
    
    
    target_indices = 21  # 你需要指定要变换的行数
    print(atom_info[:21])
    print("****************************************")
    
    output_dir = 'output_files'
    os.makedirs(output_dir, exist_ok=True)

    for step in range(1, 11):
        new_atom_info = transform_coordinates(atom_info, target_indices, step)
        #print(new_atom_info)
        output_file = os.path.join(output_dir, f'step_{step}.vas')

        
        with open(output_file, 'w') as fo:
            
            with open(input_file, 'r') as fi:
                for i in range(8):
                    line = fi.readline()
                    fo.write(line)
                        
                        
        with open(output_file, 'a') as f:               
            for line in new_atom_info:
                f.write('  ' + '  '.join(line) + '\n')


if __name__ == '__main__':
    main()